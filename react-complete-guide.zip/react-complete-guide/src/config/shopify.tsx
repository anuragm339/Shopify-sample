export enum ProductFilterCategory {
  ALL = "",
  UNPUBLISHED = "published_status:unpublished",
  PUBLISHED = "published_status:published",
}

export interface IProductFilter {
  label: string;
  filterCategory: ProductFilterCategory;
}

export const ProductFilterBy: IProductFilter[] = [
  {
    label: "All",
    filterCategory: ProductFilterCategory.ALL
  },
  {
    label: "Published",
    filterCategory: ProductFilterCategory.PUBLISHED
  },
  {
    label: "Unpublished",
    filterCategory: ProductFilterCategory.UNPUBLISHED
  }
];
