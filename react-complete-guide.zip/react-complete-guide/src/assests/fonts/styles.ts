import createUseStyles from "@picsart/rc/create";
import { deepMergeStyles, selection } from "@picsart/rc/helpers";
import resets from "@picsart/rc/resets";
import colors from "@picsart/rc/colors";
import aimStyles from "@picsart/rc/aim";
import { GilroyFonts, withFontFamily } from "@picsart/rc/fonts";

const useStyles = createUseStyles(
  {
    ...deepMergeStyles(resets, selection(), colors, aimStyles, withFontFamily(GilroyFonts))
  },
  {
    name: "app"
  }
);

export default useStyles;
