export { default } from "./GridContent";
