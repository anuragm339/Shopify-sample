import React from "react";

import GridContent from "./gridcontent";

const GridLayout = () => {
  const productBackupData = [
    {
      id:1,
      productName: "Backup1",
      previousName: "Backup",
      tags: "updateTags1"
    },
    {
      id:2,
      productName: "Backup2",
      previousName: "Backup1",
      tags: "updateTags"
    },
    {
      id:3,
      productName: "Backup3",
      previousName: "Backup2",
      tags: "updateTags"
    },
    {
      id:4,
      productName: "Backup4",
      previousName: "Backup3",
      tags: "updateTags"
    }
  ];
  return (
    <>
      {productBackupData.map((item,i) => (
        <GridContent key={i} data={item} />
      ))}

    </>
  );
};

export default GridLayout;
