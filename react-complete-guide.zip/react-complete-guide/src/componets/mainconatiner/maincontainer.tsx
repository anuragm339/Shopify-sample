import React, { useEffect, useState } from "react";

import HeaderSection from "../headers/HeaderSection";
import Sidebar from "../sidebar";
import { configureDefaultTheme } from "../../themes";
import UserProfile from "../Profile";
import ProductBackupDisplay from "../productbacukpdisplay/ProductBackupDisplay";
import NoProductDisplay from "../noproductdisplay/NoProductDisplay";

import useStyles from "./maincontainer.styles";

const MainContainer = () => {
  const classes = useStyles();
  const [click, setClick] = useState(false);
  const onChange = (isClicked: boolean) => {
    setClick(isClicked);
  };
  console.log("click", click);
  useEffect(() => {
    configureDefaultTheme();
  }, []);
  return (

    <>
      <div className={classes.header}>
        <UserProfile />
        <HeaderSection />
      </div>
      <div className={classes.main}>
        <Sidebar onClick={onChange}></Sidebar>
        {click === true && (
          <ProductBackupDisplay></ProductBackupDisplay>
        )}
        <NoProductDisplay></NoProductDisplay>
        {/*  */}
      </div>
      {/* <AlertModal /> */}
    </>
  );
};
export default MainContainer;
