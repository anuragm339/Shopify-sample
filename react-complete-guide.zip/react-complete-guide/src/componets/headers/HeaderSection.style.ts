import { createUseStyles } from "react-jss";

export default createUseStyles({
  actionContainer: {
    backgroundColor: "var(--pa-color-2)",
    borderRadius: "0.5rem", // 8px
    display: "flex",
    flexDirection: "column",
    alignItems: "stretch",
    gap: "1rem", // 16px
    padding: "0rem", // 16px
    position: "relative",
    width: "100%",
    "&[data-active=false]": {
      pointerEvents: "none",
      "& *": {
        opacity: 0.9
      }
    }
  },
  row: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "1rem", // 16px
    width: "100%"
  }
});
