import React from "react";

import SortIcon from "../../assests/icon/SortIcon";
import Dropdown, { IDropdownItem } from "../common/dropdown/DropDown";

const ProductSort = () => {

  const dropdownItems: IDropdownItem[] = [];

  return <Dropdown items={dropdownItems} icon={<SortIcon />} isDisabled={false} testId="productSort" />;
};

export default ProductSort;
