import React from "react";

import UpgradeIcon from "../../assests/icon/UpgradeIcon";
import PicsartIcon from "../../assests/icon/PicsartIcon";

import useStyles from "./UserProfile.styles";

const UserProfile = () => {
  const classes = useStyles();

  return (
    <>
      <div className={classes.logoContainer}>
        <div className={classes.logoBlock} data-test="Profile">
          <div className={classes.logo} data-test="LogoIcon">
            <PicsartIcon />
          </div>
          {false ? (
            <div className={classes.emptyBlock} />
          ) : (
            <button className={classes.upgradeBtn} data-test="UpgradeBtn">
              <UpgradeIcon />
              'Try For Free'
            </button>
          )}
        </div>
        <div className={classes.pricingLink} data-test="PricingBlock">
          <div className={classes.priceInfo} data-test="PriceInfo">

          </div>
        </div>
      </div>
    </>
  );
};

export default UserProfile;
