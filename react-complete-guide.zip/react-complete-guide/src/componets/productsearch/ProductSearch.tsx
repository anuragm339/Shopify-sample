import React from "react";

import Search from "../common/search/Search";


const ProductSearch = () => {

  return <Search />;
};

export default ProductSearch;
