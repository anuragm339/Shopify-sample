import React, { useState } from "react";


import useStyles from "./productsidebarcontent.style";

export interface Product {
  label: string;
  icon: JSX.Element;
  isDisabled?: boolean;
  onClick: (b: boolean) => void;
  data:any
}

const ProductSideBarContent = ({ label, icon, isDisabled = false, onClick }: Product) => {
  const classes = useStyles();
  const [labels, setLabels] = useState(label);
  const clickHandler = () => {
    onClick(true)
    console.log("Click Handle");
  };
  return (
    <li className={classes.menuItem} data-disabled={isDisabled} onClick={clickHandler}>
      <span>{icon}</span>
      <label>{labels}</label>
    </li>
  );
};

export default ProductSideBarContent;
