import React from "react";

import useStyles from "./ProductSideBar.style";
import ProductSideBarContent from "./productsidebardicontent/productsidebarcontent";

export interface ProductSideBarContents{
  onClick:(value:boolean)=>void
}
const ProductSideBar = ({ onClick }:ProductSideBarContents) => {
  const onClicked = (isClick: boolean) => {
    onClick(isClick);
  };
  const classes = useStyles();

  const menuItems: any[] = [

    {
      id:1,
      icon: "ABC",
      label: "Product 1"
    },
    {
      id:2,
      icon: "ABC",
      label: "Product 2"
    },

    {
      id:3,
      icon: "ABC",
      label: "Product 3"
    },
    {
      id:4,
      icon: "ABC",
      label: "Product 4"
    },

    {
      id:5,
      icon: "ABC",
      label: "Product 5"
    }

  ];
  return (
    <ul className={classes.menu}>
      {menuItems.map(item => (
        <ProductSideBarContent key={item.id} {...item} onClick={onClicked} />
      ))}
    </ul>
  );
};

export default ProductSideBar;
