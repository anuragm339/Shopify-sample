import React from "react";

import GridLayout from "../gridcontainer";

import useStyles from "./ProductBackupDisplay.style";


const ProductBackupDisplay = (prop: any) => {
  const classes = useStyles();
  return (
    <div className={classes.gridContainer}>
      <GridLayout></GridLayout>
    </div>
  );
};

export default ProductBackupDisplay;
