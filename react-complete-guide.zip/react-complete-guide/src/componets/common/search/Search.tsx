import React, { useCallback, useState } from "react";

import SearchIcon from "../../../assests/icon/SearchIcon";

import useStyles from "./Search.styles";

interface ISearch {
  defaultValue?: string;
  placeHolder?: string;
  isDisabled?: boolean;
  onSearch: (value: string) => void;
  onClear?: () => void;
}

const Search = () => {
  const classes = useStyles();

  const [showClear, setShowClear] = useState(false);

  const inputRef = useCallback((el?: HTMLInputElement) => {
    if (el?.value) setShowClear(true);
    return el;
  }, []);

  return (
    <div className={classes.searchContainer}>
      <SearchIcon />
      <input data-testid="searchProduct" defaultValue="" placeholder="" className={classes.searchInput} />
    </div>
  );
};

export default Search;



