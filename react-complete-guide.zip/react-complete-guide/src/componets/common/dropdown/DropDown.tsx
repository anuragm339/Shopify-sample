import React from "react";

import DownArrowIcon from "../../../assests/icon/DownArrowIcon";

import useStyles from "./DropDown.style";

export interface IDropdownItem {
  label: string;
  onSelect: () => void;
  isSelected: boolean;
}

interface IDropdown {
  items: IDropdownItem[];
  icon?: JSX.Element;
  isDisabled?: boolean;
  testId?: string;
}

const Dropdown = ({ items, icon, isDisabled = false, testId = "dropdown" }: IDropdown) => {
  const classes = useStyles();

  return (
    <div className={classes.dropdown}>
      <button data-open={true} className={classes.dropdownBtn} disabled={isDisabled}>
        <DownArrowIcon />
      </button>
    </div>
  );
};

export default Dropdown;
