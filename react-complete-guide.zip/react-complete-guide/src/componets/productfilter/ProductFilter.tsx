import React from "react";

import FilterIcon from "../../assests/icon/FilterIcon";
import Dropdown, { IDropdownItem } from "../common/dropdown/DropDown";

const ProductFilter = () => {
  const dropdownItems: IDropdownItem[] = [];

  return <Dropdown items={dropdownItems} icon={<FilterIcon />} isDisabled={false} testId="productFilter" />;
};
export default ProductFilter;
