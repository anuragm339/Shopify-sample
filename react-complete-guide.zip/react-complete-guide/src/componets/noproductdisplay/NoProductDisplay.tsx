import React from "react";

const NoProductDisplay = () =>{

  return(
    <>
    <div>

    </div>
    </>
  )
}

export default NoProductDisplay;
