import React from "react";

import ProductSideBar from "../products/ProductSideBar";

import useStyles from "./SideBar.styles";

export interface SideBarContent{
  onClick:(value:boolean)=>void
}
const SideBar = ({ onClick }:SideBarContent) => {
  const onClicked=(isClicked:boolean)=>{
    onClick(isClicked);
  }
  const classes = useStyles();
  return (
    <>
      <div className={classes.sidebar}>
        <div className={classes.body} data-disabled={"false"}>
          <ProductSideBar onClick={onClick}></ProductSideBar>
        </div>
      </div>
    </>
  );
};

export default SideBar;
