import { CSSColorsLight } from "./colors";
import { CSSspacings } from "./spacings";
import { CSSRadiuses } from "./radiuses";

const styleClasses = {
  colors: "pa-color-theme",
  spacings: "pa-spacing-theme",
  radius: "pa-radius-theme"
};

const htmlClasses = {
  dark: "dark",
  light: "light"
};

const cleanupExistingStyles = () => {
  Object.values(styleClasses).forEach(el => {
    const existingStyle = document.getElementsByClassName(el);
    if (existingStyle.length) {
      existingStyle[0].remove();
    }
  });
};

export const updateColors = (options: Record<string, string>) => {
  const root = document.documentElement;
  const head = document.getElementsByTagName("head")[0];

  const style = document.createElement("style");
  style.classList.add(styleClasses.colors);
  style.innerHTML = `${Object.entries(options).reduce((result, [key, value]) => `${result}${key}: ${value};`, ":root.css-colors { ")}}`;
  head.appendChild(style);
  root.classList.add("css-colors");
};

export const updateSpacings = (options: Record<string, string>) => {
  const root = document.documentElement;
  const head = document.getElementsByTagName("head")[0];

  const style = document.createElement("style");
  style.classList.add(styleClasses.spacings);
  style.innerHTML = `${Object.entries(options).reduce((result, [key, value]) => `${result}${key}: ${value};`, ":root.css-spacings { ")}}`;
  head.appendChild(style);
  root.classList.add("css-spacings");
};

const updateRadiuses = (options: Record<string, string>) => {
  const root = document.documentElement;
  const head = document.getElementsByTagName("head")[0];

  const style = document.createElement("style");
  style.classList.add(styleClasses.radius);
  style.innerHTML = `${Object.entries(options).reduce((result, [key, value]) => `${result}${key}: ${value};`, ":root.css-radiuses { ")}}`;
  head.appendChild(style);
  root.classList.add("css-radiuses");
};

const updateHtmlClassName = (className: string) => {
  const htmlElement = document.querySelectorAll("html")[0];
  Object.values(htmlClasses).forEach(el => {
    htmlElement.classList.remove(el);
  });
  htmlElement.classList.add(className);
};

export const configureDefaultTheme = () => {
  cleanupExistingStyles();
  updateHtmlClassName(htmlClasses.dark);
  updateColors(CSSColorsLight);
  updateSpacings(CSSspacings);
  updateRadiuses(CSSRadiuses);
};
