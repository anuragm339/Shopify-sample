const prefix = "--pa-spacing-";
const keyPrefix = "paSpacing";

const sizeUnit = "px";

const CSSspacings = {
  [`${prefix}1x`]: `2${sizeUnit}`,
  [`${prefix}2x`]: `4${sizeUnit}`,
  [`${prefix}3x`]: `8${sizeUnit}`,
  [`${prefix}4x`]: `12${sizeUnit}`,
  [`${prefix}5x`]: `16${sizeUnit}`,
  [`${prefix}6x`]: `24${sizeUnit}`,
  [`${prefix}7x`]: `32${sizeUnit}`,
  [`${prefix}8x`]: `40${sizeUnit}`,
  [`${prefix}9x`]: `44${sizeUnit}`,
  [`${prefix}10x`]: `48${sizeUnit}`,
  [`${prefix}11x`]: `56${sizeUnit}`,
  [`${prefix}12x`]: `64${sizeUnit}`,
  [`${prefix}13x`]: `72${sizeUnit}`,
  [`${prefix}14x`]: `20${sizeUnit}`
};

const spacings = Object.keys(CSSspacings).reduce<Record<string, string>>(
  (result, spacing: string) => {
    const spacingIndex = spacing.split(prefix)[1];
    // eslint-disable-next-line
    result[`${keyPrefix}${spacingIndex}`] = `var(${spacing})`;
    return result;
  },
  {}
);

export { CSSspacings, spacings };
