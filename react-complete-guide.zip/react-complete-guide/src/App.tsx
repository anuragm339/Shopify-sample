import * as React from "react";

import MainContainer from "./componets/mainconatiner";

type AppProps = { num: number };

export const App = ({ num }: AppProps) => <MainContainer></MainContainer>;
