// @ts-ignore
import createUseStyles from "@picsart/rc/create";
// @ts-ignore
import { deepMergeStyles, selection } from "@picsart/rc/helpers";
// @ts-ignore
import resets from "@picsart/rc/resets";
// @ts-ignore
import colors from "@picsart/rc/colors";
// @ts-ignore
import aimStyles from "@picsart/rc/aim";
// @ts-ignore
import { GilroyFonts, withFontFamily } from "@picsart/rc/fonts";

const useStyles = createUseStyles(
  {
    ...deepMergeStyles(resets, selection(), colors, aimStyles, withFontFamily(GilroyFonts))
  },
  {
    name: "app"
  }
);

export default useStyles;
