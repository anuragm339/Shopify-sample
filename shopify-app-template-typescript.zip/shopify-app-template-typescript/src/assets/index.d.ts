// Put here extensions used for assets
declare module "*.png";
