import React from "react";

import ProductSearch from "../productsearch/ProductSearch";
import ProductFilter from "../productfilter";
import ProductSort from "../productsort/ProductSort";

import useStyles from "./HeaderSection.style";

const HeaderSection = () => {
  const classes = useStyles();
  // const { pageStage } = useSelector(getPage);
  return (
    <div className={classes.actionContainer}>
      <div className={classes.row}>
        <ProductFilter />
        <ProductSort />
      </div>
      <div className={classes.row}>
        <ProductSearch />
      </div>
    </div>

  );
};

export default HeaderSection;
