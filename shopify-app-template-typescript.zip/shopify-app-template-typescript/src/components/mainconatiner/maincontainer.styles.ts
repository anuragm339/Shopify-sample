import { createUseStyles } from "react-jss";

export default createUseStyles({
  header: {
    display: "flex",
    gap: "0.25rem", // 8px
    height: "7.5rem", // 120px
    width: "100%"
  },
  main: {
    display: "flex",
    gap: "1.5%", // 8px
    marginTop: "10px",
    width: "100%"
  }
});
