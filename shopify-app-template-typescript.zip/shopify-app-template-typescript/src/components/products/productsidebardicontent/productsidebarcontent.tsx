import React, { useState } from "react";


import useStyles from "./productsidebarcontent.style";

export interface Product {
  title: string;
  imageCdn: string;
  isDisabled?: boolean;
  onClick: (b: boolean) => void;
  id: string,
}

const ProductSideBarContent = ({ title, imageCdn, isDisabled = false, onClick,id }: Product) => {
  const classes = useStyles();
  const [labels, setLabels] = useState(title);
  console.log("Value of Id",id);
  const clickHandler = () => {
    onClick(true)
    console.log("Click Handle",id);
  };
  return (
    <li className={classes.menuItem} data-disabled={isDisabled} onClick={()=>clickHandler()}>
      <span>
         <label className={classes.padding}>{labels}</label>
        <img src={imageCdn} width={20} height={20}/>
      </span>
    </li>
  );
};

export default ProductSideBarContent;
