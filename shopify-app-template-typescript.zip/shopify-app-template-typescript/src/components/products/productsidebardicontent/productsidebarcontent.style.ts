import { createUseStyles } from "react-jss";

export default createUseStyles({
  menuItem: {
    backgroundColor: "transparent",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: "0.25rem", // 4px
    listStyle: "none",
    padding: "0.25rem 0",
    cursor: "pointer",
    "& > label": {
      fontSize: "0.75rem" // 12px
    },
    "& > span": {
      height: "1.5rem", // 24px
      width: "100%" // 24px
    },
    "&[data-disabled=true]": {
      pointerEvents: "none",
      opacity: 0.7
    },
    width:"100%",
    height: "calc(100vh - 160px)"
  },
  padding:{
    paddingRight:"20px"
  }
});
