import React from "react";

import useStyles from "./ProductSideBar.style";
import ProductSideBarContent from "./productsidebardicontent/productsidebarcontent";
import {useProducts} from "../../graphql/hooks/products";
import {IMAGES_PER_PRODUCT, PAGE_SIZE} from "../../config/constants";
import {ProductFilterBy, ProductSortBy} from "../../config/constants/shopify";

export interface ShopifyFetchProductResponse{
  title:string,
  id:string,
  imageCdn:string;

}

export interface ProductSideBarContents{
  onClick:(value:boolean)=>void
}

const ProductSideBar = ({ onClick }:ProductSideBarContents) => {

  const onClicked = (isClick: boolean) => {
    onClick(isClick);
  };

  const queryVariables = {
    pageSize: PAGE_SIZE,
    imageCount: IMAGES_PER_PRODUCT,
    pageCursor: undefined,
    searchBy:'',
    filterBy:ProductFilterBy[0],
    sortBy:ProductSortBy[11],
  };

  const { loading, data, error, refetch } = useProducts(queryVariables);
  console.log('data updated data ',data?.products.edges);
  const classes = useStyles();

  const shopifyProductResponse: ShopifyFetchProductResponse[]=data?.products?.edges?.map(value => {
    return {
      title:value.node.title,
      id:value.node.id,
      imageCdn:value?.node?.images?.edges[0]?.node?.url
    }
  });
  if(typeof shopifyProductResponse !== "undefined") {
    shopifyProductResponse.push(shopifyProductResponse[1]);
    shopifyProductResponse.push(shopifyProductResponse[2]);
    shopifyProductResponse.push(shopifyProductResponse[3]);
    shopifyProductResponse.push(shopifyProductResponse[4]);
    shopifyProductResponse.push(shopifyProductResponse[5]);
    shopifyProductResponse.push(shopifyProductResponse[2]);
    shopifyProductResponse.push(shopifyProductResponse[6]);
    shopifyProductResponse.push(shopifyProductResponse[9]);
    shopifyProductResponse.push(shopifyProductResponse[3]);
  }


  console.log('shopifyProductResponse',shopifyProductResponse);


  return (
    <ul className={classes.menu}>
      {shopifyProductResponse?.map((item,index) => (
        <ProductSideBarContent key={index}  onClick={onClicked} {...item}/>
      ))}
    </ul>
  );
};

export default ProductSideBar;
