import { createUseStyles } from "react-jss";

export default createUseStyles({
  menu: {
    backgroundColor: "transparent",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    gap: "0.5rem", // 8px
    height: "calc(100vh - 160px)",
    padding: "0.25rem 0", // 4px
    position: "fixed",
    overflow:"auto"

  }

});
