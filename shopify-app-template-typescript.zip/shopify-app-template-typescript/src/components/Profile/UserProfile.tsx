import React from "react";



import useStyles from "./UserProfile.styles";
import PicsartIcon from "../../assets/icon/PicsartIcon";
import UpgradeIcon from "../../assets/icon/UpgradeIcon";

const UserProfile = () => {
  const classes = useStyles();

  return (
    <>
      <div className={classes.logoContainer}>
        <div className={classes.logoBlock} data-test="Profile">
          <div className={classes.logo} data-test="LogoIcon">
            <PicsartIcon />
          </div>
          {false ? (
            <div className={classes.emptyBlock} />
          ) : (
            <button className={classes.upgradeBtn} data-test="UpgradeBtn">
              <UpgradeIcon />
              'Try For Free'
            </button>
          )}
        </div>
        <div className={classes.pricingLink} data-test="PricingBlock">
          <div className={classes.priceInfo} data-test="PriceInfo">

          </div>
        </div>
      </div>
    </>
  );
};

export default UserProfile;
