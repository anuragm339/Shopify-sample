import { createUseStyles } from "react-jss";

export default createUseStyles({
  logoContainer: {
    width: "24%",
    marginRight: "1%",
    padding: "var(--pa-spacing-4x)",
    background: "var(--pa-color-2)",
    borderRadius: "var(--pa-radius-3x)",
    position: "relative"
  },
  logoBlock: {
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "space-between",
    borderBottom: "1px solid var(--pa-color-13)",
    marginBottom: "var(--pa-spacing-4x)"
  },
  logo: {
    margin: "3px 16px 16px 13px"
  },
  emptyBlock: {
    width: "110px"
  },
  upgradeBtn: {
    background: "var(--pa-color-6)",
    fontWeight: "600",
    color: "var(--pa-color-9)",
    padding: "6px 12px 6px 40px",
    borderRadius: "var(--pa-radius-4x)",
    border: "none",
    position: "relative",
    lineHeight: "20px",
    cursor: "pointer",
    "& svg.icon": {
      position: "absolute",
      top: "5px",
      left: "13px"
    }
  },
  priceInfo: {
    width: "12.5rem",
    textAlign: "left",
    fontSize: "0.75rem", // 12px
    lineHeight: 1.17, // 16px
    marginTop: "5px",
    fontWeight: "600",
    color: "var(--pa-color-5)"
  },
  pricingLink: {
    display: "flex",
    alignItems: "baseline",
    justifyContent: "space-between",
    margin: "0 15px",
    textAlign: "right"
  },
  pricingTitle: {
    fontSize: "14px",
    fontWeight: 600,
    color: "var(--pa-color-1)",
    cursor: "pointer"
  }
});
