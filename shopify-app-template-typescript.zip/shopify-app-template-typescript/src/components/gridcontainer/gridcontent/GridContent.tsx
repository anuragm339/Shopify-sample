import React, { useState } from "react";

import useStyles from "./GridContent.style";
export interface GridData{
  data:any
}// eslint-disable-next-line @typescript-eslint/no-shadow
const GridContent = ({ data }: GridData) => {
  console.log(data.id);
  const classes = useStyles();
  return (
    <>
      <div className="card">
        <img key={`${data.id}`} alt={data.productName} src="https://cdn140.picsart.com/bg.svg" />
      </div>
    </>
  );
};
export default GridContent;
