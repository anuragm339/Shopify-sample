export { default } from './NoProductDisplay'
