import { createUseStyles } from "react-jss";

export default createUseStyles({
  sidebar: {
    backgroundColor: "var(--pa-color-18)",
    borderRadius: "0.75rem", // 12px
    boxSizing: "border-box",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "space-between",
    flexGrow: 1,
    gap: "1rem", // 16px
    padding: "1rem", // 16px
    width: "25.7%", // 322px,
    "&[data-minimize=true]": {
      width: "5rem", // 80px
      padding: "1rem 0.25rem" // 16px 4px
    },
    "& > [data-disabled=true]": {
      pointerEvents: "none",
      opacity: 0.7
    },
    height: "calc(100vh - 160px)",
  },
  header: {
    alignSelf: "flex-start",
    color: "var(--pa-color-4)",
    fontSize: "1.25rem", // 20px
    fontWeight: 600,
    lineHeight: "1.75rem" // 28px
  },
  body: {
    overflow: "auto",
    flexGrow: 1,
    width: "100%",
    "& > *": {
      display: "flex",
      flexDirection: "column",
      gap: "16px"
    },
    height: "calc(100vh - 160px)"
  },
  footer: {
    backgroundColor: "transparent",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "0.25rem", // 4px
    height: "2rem", // 32px
    width: "100%",
    "& > :last-child": {
      width: "100%"
    },
    "& > *": {
      height: "100%"
    }
  },
  subTitle: {
    fontSize: "14px",
    fontWeight: "600",
    color: "var(--pa-color-4)",
    lineHeight: "20px",
    marginBottom: "5px"
  }
});
