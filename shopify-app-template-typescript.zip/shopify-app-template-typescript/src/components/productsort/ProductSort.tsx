import React from "react";


import Dropdown, { IDropdownItem } from "../common/dropdown/DropDown";
import SortIcon from "../../assets/icon/SortIcon";

const ProductSort = () => {

  const dropdownItems: IDropdownItem[] = [];

  return <Dropdown items={dropdownItems} icon={<SortIcon />} isDisabled={false} testId="productSort" />;
};

export default ProductSort;
