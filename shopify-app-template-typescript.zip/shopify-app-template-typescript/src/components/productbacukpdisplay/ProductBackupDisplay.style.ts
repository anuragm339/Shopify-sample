import { createUseStyles } from "react-jss";

export default createUseStyles({
  gridContainer: {
    display: "grid",
    flexDirection: "column",
    gap: "1rem",
    backgroundColor: "var(--pa-color-18)",
    borderRadius: "var(--pa-radius-3x)",
    height: "calc(100vh - 160px)",
    width: "100%",
    padding: "1rem", // 16px,
    overflow: "auto",
    gridTemplateColumns: " repeat(3, 1fr)"
  },
  actionBar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between"
  },
  actionBarDisplay: {
    display: "flex",
    alignItems: "center",
    gap: "0.5rem", // 8px
    lineHeight: "1.5rem", // 24px
    "& > p": {
      fontSize: "1rem" // 16px
    },
    "& > p:first-child": {
      color: "var(--pa-color-22)"
    },
    "& > p:not(first-child)": {
      color: "var(--pa-color-23)"
    }
  },
  actionBarActions: {
    display: "flex",
    gap: "1rem" // 16px
  },
  privacyFooter: {
    position: "absolute",
    bottom: "2px",
    left: "43%"
  },
  link: {
    color: "var(--pa-color-1)"
  },
  hideBannerArrow: {
    backgroundColor: "white",
    borderRadius: "50%",
    width: 30,
    height: 30,
    boxShadow: "0px 1px 7px rgb(17 18 54 / 19%)",
    padding: "5px 8px",
    cursor: "pointer"
  },
  hideBannerArrowActive: {
    backgroundColor: "white",
    borderRadius: "50%",
    width: 30,
    height: 30,
    boxShadow: "0px 1px 7px rgb(17 18 54 / 19%)",
    padding: "5px 8px",
    cursor: "pointer",
    transform: "scaleY(-1)"
  }
});
