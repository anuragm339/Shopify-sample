import React from "react";


import Dropdown, { IDropdownItem } from "../common/dropdown/DropDown";
import FilterIcon from "../../assets/icon/FilterIcon";

const ProductFilter = () => {
  const dropdownItems: IDropdownItem[] = [];

  return <Dropdown items={dropdownItems} icon={<FilterIcon />} isDisabled={false} testId="productFilter" />;
};
export default ProductFilter;
