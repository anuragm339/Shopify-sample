import { createUseStyles } from "react-jss";

export default createUseStyles({
  searchContainer: {
    position: "relative",
    display: "flex",
    alignItems: "center",
    width: "100%",
    "& > svg:first-child": {
      position: "absolute",
      left: 0,
      marginLeft: "0.75rem", // 12px
      height: "1rem", // 16px
      width: "1rem" // 16px
    },
    "& > span": {
      position: "absolute",
      margin: 0,
      right: 0,
      marginRight: "0.75rem", // 12px
      height: "1rem", // 16px
      width: "1rem", // 16px
      cursor: "pointer"
    }
  },
  searchInput: {
    backgroundColor: "transparent",
    border: "0.063rem solid var(--pa-color-3)", // 1px
    borderRadius: "0.75rem", // 12px
    color: "var(--pa-color-4)",
    fontSize: "0.875rem", // 14px
    fontWeight: 500,
    padding: "0.5rem 2.5rem 0.5rem 2.5rem", // 8px 12px 8px 40px
    width: "100%"
  }
});
