import { createUseStyles } from "react-jss";

export default createUseStyles({
  dropdown: {
    position: "relative",
    width: "100%",
    "& button": {
      backgroundColor: "transparent",
      cursor: "pointer",
      width: "100%",
      "&:disabled": {
        cursor: "default"
      }
    }
  },
  dropdownBtn: {
    border: "0.063rem solid var(--pa-color-3)", // 1px
    borderRadius: "0.75rem", // 12px
    display: "flex",
    alignItems: "center",
    padding: "0.5rem 0.75rem", // 8px 12px
    "& > p": {
      color: "var(--pa-color-4)",
      fontSize: "0.875rem", // 14px
      fontWeight: 500,
      marginLeft: "0.75rem", // 12px
      marginRight: "auto"
    },
    "& > :last-child": {
      transition: "all 0.3s ease-in"
    },
    "&[data-open=true] > :last-child": {
      transform: "rotate(180deg)"
    },
    "& > svg": {
      width: "1rem", // 16px
      height: "1rem" // 16px
    }
  },
  dropdownContainer: {
    backgroundColor: "var(--pa-color-9)",
    border: "0.063rem solid var(--pa-color-3)", // 1px
    borderRadius: "0.75rem", // 12px
    position: "absolute",
    top: "2.375rem", // 38px
    width: "100%",
    overflow: "auto",
    zIndex: 1
  },
  dropdownItem: {
    border: "none",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "0.5rem 0.75rem", // 8px 12px
    transition: "all .5s ease-in-out",
    textDecoration: "none",
    fontSize: "0.75rem", // 14px
    fontWeight: "600",
    lineHeight: "1.25rem", // 20px
    "& > svg > path": {
      fill: "var(--pa-color-5)"
    },
    "&:hover": {
      backgroundColor: "var(--pa-color-13)"
    }
  }
});
