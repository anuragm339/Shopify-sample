import React from "react";



import useStyles from "./DropDown.style";
import DownArrowIcon from "../../../assets/icon/DownArrowIcon";

export interface IDropdownItem {
  label: string;
  onSelect: () => void;
  isSelected: boolean;
}

interface IDropdown {
  items: IDropdownItem[];
  icon?: JSX.Element;
  isDisabled?: boolean;
  testId?: string;
}

const Dropdown = ({ items, icon, isDisabled = false, testId = "dropdown" }: IDropdown) => {
  const classes = useStyles();

  return (
    <div className={classes.dropdown}>
      <button data-open={true} className={classes.dropdownBtn} disabled={isDisabled}>
        <DownArrowIcon />
      </button>
    </div>
  );
};

export default Dropdown;
