const prefix = "--pa-radius-";
const keyPrefix = "paRadius";

const sizeUnit = "px";

const CSSRadiuses = {
  [`${prefix}1x`]: `4${sizeUnit}`,
  [`${prefix}2x`]: `8${sizeUnit}`,
  [`${prefix}3x`]: `12${sizeUnit}`,
  [`${prefix}4x`]: `16${sizeUnit}`,
  [`${prefix}5x`]: `24${sizeUnit}`,
  [`${prefix}6x`]: `72${sizeUnit}`
};

const radiuses = Object.keys(CSSRadiuses).reduce<Record<string, string>>(
  (result, radius: string) => {
    const radiusIndex = radius.split(prefix)[1];
    // eslint-disable-next-line
    result[`${keyPrefix}${radiusIndex}`] = `var(${radius})`;
    return result;
  },
  {}
);

export { CSSRadiuses, radiuses };
