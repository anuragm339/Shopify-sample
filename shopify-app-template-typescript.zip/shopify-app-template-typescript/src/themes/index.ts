import { colors, getColor } from "./colors";
import { spacings } from "./spacings";
import { radiuses } from "./radiuses";

const baseTheme = {
  getColor,
  spacings,
  radiuses
};

const lightTheme = {
  default: {
    ...baseTheme,
    colors
  }
};

export { lightTheme };

export * from "./utils";
