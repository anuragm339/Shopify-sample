const prefix = "--pa-color-";
const keyPrefix = "paColor";

const mainColors = {
  [`${prefix}1`]: "#C209C1",
  [`${prefix}2`]: "#F8F8F8",
  [`${prefix}3`]: "#CBCBCB",
  [`${prefix}4`]: "#5F5F5F",
  [`${prefix}5`]: "#080808",
  [`${prefix}6`]: "#009E9C",
  [`${prefix}7`]: "#7C7C7C",
  [`${prefix}8`]: "#E0E0E0",
  [`${prefix}9`]: "#FFFFFF",
  [`${prefix}10`]: "#000000",
  [`${prefix}11`]: "#E79DE6",
  [`${prefix}12`]: "#EEEEEE",
  [`${prefix}13`]: "#F0F0F0",
  [`${prefix}14`]: "#A0A0A3",
  [`${prefix}15`]: "#E3E3E3",
  [`${prefix}16`]: "#F6E8F1",

  [`${prefix}17`]: "#F7F7F7",
  [`${prefix}18`]: "#FCFCFC",

  [`${prefix}19`]: "#B7B7B7",
  [`${prefix}20`]: "#C9C9C9",
  [`${prefix}21`]: "#5A00EE",
  [`${prefix}22`]: "#4C4C4c",
  [`${prefix}23`]: "#999999",

  [`${prefix}24`]: "#158423",
  [`${prefix}25`]: "#FE9D24",
  [`${prefix}26`]: "#D31E2A"
};

const CSSColorsLight = {
  ...mainColors
};

const getColor = (colorKey: string) => {
  const reg = /^var\((.+)\)$/;
  const colorIndex = colorKey.replace(reg, "$5");
  const colorHex = CSSColorsLight[colorIndex];
};
const generateColors = (colors: Record<string, string>) =>
  Object.keys(colors).reduce<Record<string, string>>((result, color: string) => {
    const colorIndex = color.split(prefix)[1];
    // eslint-disable-next-line no-param-reassign
    result[`${keyPrefix}${colorIndex}`] = `var(${color})`;
    return result;
  }, {});
const colors = generateColors(CSSColorsLight);

export { CSSColorsLight, colors, getColor };
