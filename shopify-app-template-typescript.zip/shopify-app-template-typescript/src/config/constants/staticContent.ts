export default {
  unsubscribedUserText: 'Make your products stand out. Try our editing tools free for 7 days.',
  subscribedUserText: 'Enjoy full access to our photo editing tools.',
  upgradeTxt: 'Upgrade',
  tryForFree: 'Start for free',
  text: 'Text',
  pricing: 'Pricing',
  displayContainer: {
    homeContent: {
      actionBarTitle: 'Select images',
      selectButton: {
        selectImages: 'Select all',
        selectAllImages: 'All images',
        selectOnlyFirstImages: 'All first images',
        deselectAllImages: 'Unselect',
      },
      noFoundMsg: {
        message: 'No products matching your filters',
        helpInfo: {
          header: 'Suggestions',
          suggestions: ['Try new filters', 'Try a different category'],
        },
        noStoreImageHeader: 'No images yet',
        noStoreImageMessage: 'To get started, make sure you have images available under Products.',
      },
    },
    editContent: {
      actionBarTitle: 'Edit images',
    },
    confirmationContent: {
      actionBarTitle: 'Select images to post',
      selectButton: {
        selectAllImages: 'Select all',
        deselectAllImages: 'Unselect',
      },
      uploadButton: {
        postToShopify: 'Post to Shopify',
      },
    },
  },
  gridContainer: {
    selectCount: (n: number) => `${n} images selected`,
    selectLimit: (n: number) => `(maximum limit of images ${n})`,
  },
  gridCard: {
    button: {
      selectAll: 'Select all',
      deselectAll: 'Unselect',
    },
    label: {
      getSelectedText: (total: number, selected: number) => `Selected ${selected}/${total}`,
    },
  },
  background: {
    label: 'Background',
    colors: 'Colors',
    error: {
      removeBg: 'Remove Background failed: Image url missing',
      applyBg: 'Apply Background failed: Image url missing',
    },
  },
  crop: {
    label: 'Crop',
    cropBy: 'Crop by',
    orientation: 'Orientation',
    align: 'Align',
    error: {
      crop: 'Crop failed: Image url or crop attributes missing',
    },
  },
  resize: {
    label: 'Resize',
    resizeBy: 'Resize by',
    targetSize: 'Target size (px)',
    padding: {
      label: 'Background',
      usePadding: 'Use padding',
      color: 'Pick a color',
    },
    error: {
      resize: 'Resize failed: Image url missing',
    },
  },
  sidebar: {
    actions: {
      back: 'Back',
      apply: 'Apply',
    },
    selectAtleastOneImage: 'Select at least one image',
  },
  backConfirmTitle: 'Leave without saving changes?',
  backConfirmDescription: 'If you leave, any unsaved changes will be lost?',
  stayOnPage: 'Stay on page',
  leaveWithoutSaving: 'Leave without saving',
  errorPostingToShopify: 'Some of the images weren’t posted. Please try again.',
  successfulPostToShopiy: 'Images successfully posted to Shopify',
};
