// import { CropOptions, ICropOptions } from '../../types/crop';
//
// const sizes = {
//   square: { width: 1, height: 1 },
//   rectangle: { width: 4, height: 3 },
// };
//
// export const CROP_TEMPLATES: ICropOptions[] = [
//   ,
// ];
