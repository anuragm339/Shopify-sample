export const PAGE_SIZE = 12;
export const IMAGES_PER_PRODUCT = 20;
export const MAX_IMAGE_SELECT_LIMIT = 30;
export const TRANSPARENT_BG_URL = 'https://cdn140.picsart.com/64814455576311042242.svg';
export const PROXY_SERVER_KEY = 'proxy_server_base_url';
export const SUBSCRIPTION_ACTIVE = 'ACTIVE';
