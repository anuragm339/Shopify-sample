import { IProductFilter, IProductSort, ProductFilterCategory, ProductSortCategory } from '../../types/shopify';

export const ProductSortBy: IProductSort[] = [
  {
    label: 'Title A-Z',
    sortCategory: ProductSortCategory.TITLE,
    reverse: false,
  },
  {
    label: 'Title Z-A',
    sortCategory: ProductSortCategory.TITLE,
    reverse: true,
  },
  {
    label: 'Product Type A-Z',
    sortCategory: ProductSortCategory.PRODUCT_TYPE,
    reverse: false,
  },
  {
    label: 'Product Type Z-A',
    sortCategory: ProductSortCategory.PRODUCT_TYPE,
    reverse: true,
  },
  {
    label: 'Vendor A-Z',
    sortCategory: ProductSortCategory.VENDOR,
    reverse: false,
  },
  {
    label: 'Vendor Z-A',
    sortCategory: ProductSortCategory.VENDOR,
    reverse: true,
  },
  {
    label: 'Inventory Total: min to max',
    sortCategory: ProductSortCategory.INVENTORY_TOTAL,
    reverse: false,
  },
  {
    label: 'Inventory Total: max to min',
    sortCategory: ProductSortCategory.INVENTORY_TOTAL,
    reverse: true,
  },
  {
    label: 'Updated: old to new',
    sortCategory: ProductSortCategory.UPDATED_AT,
    reverse: false,
  },
  {
    label: 'Updated: new to old',
    sortCategory: ProductSortCategory.UPDATED_AT,
    reverse: true,
  },
  {
    label: 'Created: old to new',
    sortCategory: ProductSortCategory.CREATED_AT,
    reverse: false,
  },
  {
    label: 'Created: new to old',
    sortCategory: ProductSortCategory.CREATED_AT,
    reverse: true,
  },
  {
    label: 'Published: old to new',
    sortCategory: ProductSortCategory.PUBLISHED_AT,
    reverse: false,
  },
  {
    label: 'Published: new to old',
    sortCategory: ProductSortCategory.PUBLISHED_AT,
    reverse: true,
  },
];

export const ProductFilterBy: IProductFilter[] = [
  {
    label: 'All',
    filterCategory: ProductFilterCategory.ALL,
  },
  {
    label: 'Published',
    filterCategory: ProductFilterCategory.PUBLISHED,
  },
  {
    label: 'Unpublished',
    filterCategory: ProductFilterCategory.UNPUBLISHED,
  },
];
