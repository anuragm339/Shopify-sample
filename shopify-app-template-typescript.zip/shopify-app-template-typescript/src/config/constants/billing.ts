export const HeaderTitle = 'A full suite of editing tools for your store';
export const SubTitle = 'Full access to the tools you need';
export const GOLD_PRICE = '$6.77/mo';
export const TC_LINK = ' https://picsart.com/terms-of-use';
export const PRIVACY_POLICY_LINK = 'https://picsart.com/privacy-policy';
export const ViewBillingHeader = 'A better way to edit images';
export const ViewBillingSubHeader = 'Improve your image editing workflow, right within Shopify. Try our editing tools free for 7 days. Enjoy: ';
export const StartFreeTrial = 'Start free trial';
export const ViewPricingCTA = 'View Pricing';

export const GoldDescription = [
  {
    id: 1,
    info: 'Remove backgrounds with a single tap.',
  },
  {
    id: 2,
    info: 'Change backgrounds to any color.',
  },
  {
    id: 3,
    info: 'Resize and upscale product photos to the exact size you need.',
  },
  {
    id: 4,
    info: 'Crop photos and create the ideal showcase for your products.',
  },
];

export const FAQS = [
  {
    id: '1',
    question: 'What are the benefits of Picsart Gold?',
    answer: 'Benefits of Picsart Gold will be disclosed soon.',
  },
  {
    id: '2',
    question: 'Do I receive the benefits of Picsart Gold on the mobile app if I purchase it from the website?',
    answer:
      // eslint-disable-next-line max-len
      'Yes! By purchasing Picsart Gold from our website you’ll receive its benefits on both mobile and web. The subscription attaches to your email address and Picsart username. So you can access Picsart Gold on your mobile device by logging in to the Picsart account you used when purchasing Picsart Gold.',
  },
  {
    id: '3',
    question: 'What are the benefits of the Picsart Team subscription?',
    answer: 'Picsart Team subscription details coming soon.',
  },
  {
    id: '4',
    question: 'Can I purchase a Picsart Team subscription if I already have a Gold subscription?',
    answer: 'Coming soon.',
  },
  {
    id: '5',
    question: 'How do I cancel my web subscription plan?',
    answer: 'Subscription cancellation details coming soon.',
  },
  {
    id: '6',
    question: "What's the refund policy?",
    answer: 'Refund policy details coming soon.',
  },
];

export const ViewBillingInfo = [
  {
    id: 1,
    info: '1- click background remover',
  },
  {
    id: 2,
    info: 'Quick and easy image resizing, cropping, and upscaling',
  },
  {
    id: 3,
    info: 'Swap in a custom background or color',
  },
];
