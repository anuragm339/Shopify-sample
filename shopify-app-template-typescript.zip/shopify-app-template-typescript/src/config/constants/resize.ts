import { IResizeTemplate, ResizeByOptions } from '../../types/resize';

const initialSizes = {
  width: 1024,
  height: 1024,
};

export const resizeLimits = {
  minWidth: 800,
  maxWidth: 4096,
  minHeight: 800,
  maxHeight: 4096,
};

export const RESIZE_TEMPLATES: IResizeTemplate[] = [
  {
    name: ResizeByOptions.WIDTH,
    sizes: { width: initialSizes.width },
  },
  {
    name: ResizeByOptions.HEIGHT,
    sizes: { height: initialSizes.height },
  },
  {
    name: ResizeByOptions.EXACT_SIZE,
    sizes: { width: initialSizes.width, height: initialSizes.height },
  },
];
