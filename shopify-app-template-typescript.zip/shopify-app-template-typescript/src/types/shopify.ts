import {FetchResult, MutationFunction} from '@apollo/client';

export interface IShopifyImage {
  node: {
    id: string;
    url: string;
    altText: string | null;
    height: number;
    width: number;
  };
}
export interface IShopifyProduct {
  cursor: string;
  node: {
    id: string;
    title: string;
    status: string;
    images: {
      edges: IShopifyImage[];
    };
  };
}

interface IShopifyPageInfo {
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

interface IShopifyProducts {
  edges: IShopifyProduct[];
  pageInfo: IShopifyPageInfo;
}

interface IShopifyShop {
  id: string;
  url: string;
  name: string;
  email: string;
}
export interface IShopifyData {
  products: IShopifyProducts;
  shop: IShopifyShop;
}

export enum ProductSortCategory {
  TITLE = 'TITLE',
  PRODUCT_TYPE = 'PRODUCT_TYPE',
  VENDOR = 'VENDOR',
  INVENTORY_TOTAL = 'INVENTORY_TOTAL',
  UPDATED_AT = 'UPDATED_AT',
  CREATED_AT = 'CREATED_AT',
  PUBLISHED_AT = 'PUBLISHED_AT',
}

export interface IProductSort {
  label: string;
  sortCategory: ProductSortCategory;
  reverse: boolean;
}

export enum ProductFilterCategory {
  ALL = '',
  UNPUBLISHED = 'published_status:unpublished',
  PUBLISHED = 'published_status:published',
}

export interface IProductFilter {
  label: string;
  filterCategory: ProductFilterCategory;
}

interface IParameter {
  name: string;
  value: string;
}

interface IStageTargetResponse {
  url: string;
  parameters: IParameter[];
}

interface ICreateLocationResponse {
  stagedUploadsCreate: {
    stagedTargets: IStageTargetResponse[];
  };
}

export interface ICreateLocation {
  (image: Blob, filename: string, stagedUploadsCreate: MutationFunction): Promise<FetchResult<ICreateLocationResponse>>;
}

export interface IUploadFile {
  (url: string, parameters: IParameter[], image: Blob): Promise<Response>;
}

export interface IUploadImageResponse {
  id: string;
  src: string;
}

interface IUpdateProductDetailsResponse {
  productImageUpdate: {
    image: IUploadImageResponse;
  };
}

export interface IUpdateProductDetails {
  (productId: string, imageId: string, imageUrl: string, productUpdate: MutationFunction): Promise<FetchResult<IUpdateProductDetailsResponse>>;
}

export interface IShopifyImageUploader {
  (imageId: string, productId: string, filename: string, image: Blob, stagedUploadsCreate: MutationFunction, productUpdate: MutationFunction): Promise<IUploadImageResponse>;
}

export interface IShopInfo {
  id: string;
  name: string;
  email: string;
}

export interface IShopData {
  shop: IShopInfo;
}
