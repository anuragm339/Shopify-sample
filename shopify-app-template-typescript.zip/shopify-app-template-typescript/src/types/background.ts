export interface IBackgroundOptions {
  bgTextureUrl?: string;
  bgColor?: string;
}

export enum BgColorActions {
  COLOR_PICKER = 'color-picker',
  TRANSPARENT = 'transparent',
}

export enum BgColors {
  COLOR1 = '#FFFFFF',
  COLOR2 = '#000000',
  COLOR3 = '#F67E06',
  COLOR4 = '#32994F',
  COLOR5 = '#110CF6',
}
