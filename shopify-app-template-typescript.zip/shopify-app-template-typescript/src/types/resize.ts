// @ts-ignore
import { ISize } from '@picsart/web-utils/types';

export enum ResizeByOptions {
  WIDTH = 'Width',
  HEIGHT = 'Height',
  EXACT_SIZE = 'Exact Size',
}

export interface IResizeTemplate {
  name: ResizeByOptions;
  sizes: Partial<ISize>;
}

export interface IResizeOptions {
  resizeTemplate: IResizeTemplate;
  resizePadding: {
    isPadding: boolean;
    color: string;
  };
}
