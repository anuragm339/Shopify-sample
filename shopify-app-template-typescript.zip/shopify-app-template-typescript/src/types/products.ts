// @ts-ignore
import { ICropAttrs } from '@picsart/web-utils/types';

export enum EditedImageBlobTypes {
  BASE_BLOB_URL = 'baseBlobUrl',
  FINAL_BLOB_URL = 'finalBlobUrl',
}

export type TEditedImageBlob = {
  [key in EditedImageBlobTypes]?: string;
};

export interface IEditedImage {
  blob?: TEditedImageBlob;
  cropAttrs?: ICropAttrs;
  isSuccess?: boolean;
  errorMsg?: string;
}

export interface IImage {
  id: string;
  productId: string;
  productName: string;
  productUrl: string;
  productStatus: string;
  src: string;
  altText: string | null;
  width: number;
  height: number;
  name: string;
  format: string;
  editedImage?: Partial<IEditedImage>;
  postToShopify?: boolean;
  isUploadSuccess?: boolean;
  isLoading?: boolean;
}

export interface IProduct {
  id: string;
  name: string;
  url: string;
  status: string;
  cursor: string;
  images: IImage[];
}

export interface IPageInfo {
  hasPreviousPage: boolean;
  hasNextPage: boolean;
}

export enum PageStage {
  HOME_PAGE = 'HOME_PAGE',
  EDIT_PAGE = 'EDIT_PAGE',
  CONFIRM_PAGE = 'CONFIRM_PAGE',
}

export enum FeatureStage {
  BACKGROUND = 'BACKGROUND',
  CROP = 'CROP',
  RESIZE = 'RESIZE',
  NO_FEATURE = '',
}

export enum ImageFileTypes {
  PNG = 'png',
}
