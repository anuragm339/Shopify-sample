// import { CropAlign, CropOrientation, ICropTemplate } from '@picsart/web-utils/types';
//
// export enum CropFeatures {
//   CROP_ALIGN = 'CROP_ALIGN',
//   CROP_ORIENTATION = 'CROP_ORIENTATION',
//   CROP_OPTION = 'CROP_OPTION',
// }
//
// export enum CropOptions {
//   FREEFORM = 'Freeform',
//   SQUARE = 'Square',
//   RECTANGLE = 'Rectangle (4:3)',
// }
//
// export interface ICropOptions extends Partial<ICropTemplate> {
//   name: CropOptions;
// }
//
// export interface ICrop {
//   cropAlign: CropAlign;
//   cropOrientation: CropOrientation;
//   cropTemplate: ICropOptions;
// }
