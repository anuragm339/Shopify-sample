// import { configureStore } from '@reduxjs/toolkit';
//
// import imageSlice from './slices/imageSlice';
// import pageSlice from './slices/pageSlice';
// import profileSlice from './slices/profileSlice';
// import alertSlice from './slices/alertSlice';
// import toasterSlice from './slices/toasterSlice';
//
// const reducer = {
//   page: pageSlice.reducer,
//   image: imageSlice.reducer,
//   profile: profileSlice.reducer,
//   alert: alertSlice.reducer,
//   toaster: toasterSlice.reducer,
// };
//
// const store = configureStore({
//   reducer,
//   middleware: getDefaultMiddleware =>
//     getDefaultMiddleware({
//       serializableCheck: false,
//     }),
// });
//
// export default store;
//
// export type RootState = ReturnType<typeof store.getState>;
// export type AppDispatch = typeof store.dispatch;
