// import type { RootState } from '../store';
//
// export const getPage = (store: RootState) => store.page;
// export const getProfile = (store: RootState) => store.profile;
// export const getImage = (store: RootState) => store.image;
// export const getAlert = (store: RootState) => store.alert;
// export const getToaster = (store: RootState) => store.toaster;
// export const getBackgroundOptions = (store: RootState) => store.image.backgroundOptions;
// export const getCropOptions = (store: RootState) => store.image.cropOptions;
// export const getResizeImageOptions = (store: RootState) => store.image.resizeOptions;
