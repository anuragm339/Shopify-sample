import gql from 'graphql-tag';

export const SHOP = gql`
  query {
    shop {
      id
      name
      email
    }
  }
`;

export default SHOP;
