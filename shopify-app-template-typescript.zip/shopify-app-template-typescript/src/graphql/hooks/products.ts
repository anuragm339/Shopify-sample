import { useQuery, useLazyQuery, QueryResult } from '@apollo/client';


import { IProductFilter, IShopifyData, IProductSort, ProductSortCategory } from '../../types/shopify';
import {FIND_PRODUCTS_QUERY_BY_PARAM} from "../productQuery";

interface IQueryVariables {
  productCount: number;
  imageCount: number;
  cursor?: string;
  query?: string;
  sortBy?: ProductSortCategory;
  reverse?: boolean;
}

interface IQueryArgs {
  pageSize: number;
  pageCursor: string;
  imageCount: number;
  searchBy: string;
  filterBy: IProductFilter;
  sortBy: IProductSort;
}

const formatVariables = ({ pageSize, imageCount, pageCursor, searchBy, filterBy: { filterCategory }, sortBy: { sortCategory, reverse } }: IQueryArgs): IQueryVariables => ({
  productCount: pageSize,
  imageCount,
  cursor: pageCursor,
  query: `${searchBy} ${filterCategory}`.trim(),
  sortBy: sortCategory,
  reverse,
});

export const useProducts = (args: IQueryArgs): QueryResult<IShopifyData> =>
  useQuery(FIND_PRODUCTS_QUERY_BY_PARAM, {
    variables: formatVariables(args),
    fetchPolicy: 'no-cache',
  });

export const getProductsOnLoad = (args: IQueryArgs) =>
  useLazyQuery(FIND_PRODUCTS_QUERY_BY_PARAM, {
    variables: formatVariables(args),
    fetchPolicy: 'no-cache',
  });
