import gql from 'graphql-tag';

export const PRODUCTS = gql`
  query products($cursor: String, $productCount: Int, $imageCount: Int!, $query: String, $reverse: Boolean, $sortBy: ProductSortKeys) {
    products(after: $cursor, first: $productCount, query: $query, reverse: $reverse, sortKey: $sortBy) {
      ...productFields
      ...pageInfoFields
    }
    shop {
      ...shopFields
    }
  }

  fragment productFields on ProductConnection {
    edges {
      cursor
      node {
        id
        title
        status
        images(first: $imageCount) {
          ...imageFields
        }
      }
    }
  }

  fragment imageFields on ImageConnection {
    edges {
      node {
        id
        url
        altText
        height
        width
      }
    }
  }

  fragment pageInfoFields on ProductConnection {
    pageInfo {
      hasNextPage
      hasPreviousPage
    }
  }

  fragment shopFields on Shop {
    id
    url
    name
    email
  }
`;

export const STAGED_UPLOADS_CREATE = gql`
  mutation stagedUploadsCreate($input: [StagedUploadInput!]!) {
    stagedUploadsCreate(input: $input) {
      stagedTargets {
        resourceUrl
        url
        parameters {
          name
          value
        }
      }
      userErrors {
        field
        message
      }
    }
  }
`;

// export const UPDATE_PRODUCT = gql`
//   mutation productImageUpdate($image: ImageInput!, $productId: ID!) {
//     productImageUpdate(image: $image, productId: $productId) {
//       image {
//         altText
//         src
//         id
//       }
//       userErrors {
//         field
//         message
//       }
//     }
//   }
// `;s
