import { DeliveryMethod,  Shopify } from "@shopify/shopify-api";


const subsWebhookResponse= async session=>await Shopify.Webhooks.Registry.register({
    path: `${process.env.SHOPIFY_BILLING_WEBHOOK}`,
    shop: session.shop,
    accessToken: session.accessToken,
    topic: 'APP_SUBSCRIPTIONS_UPDATE',
    deliveryMethod: DeliveryMethod.EventBridge,
  }
);

const oneTimeWebhook=async session=>await Shopify.Webhooks.Registry.register({
    path: `${process.env.SHOPIFY_BILLING_WEBHOOK}`,
    shop: session.shop,
    accessToken: session.accessToken,
    topic: 'APP_PURCHASES_ONE_TIME_UPDATE',
    deliveryMethod: DeliveryMethod.EventBridge,
  }
);

const shopifyProductUpdate=async session=>await Shopify.Webhooks.Registry.register({
    path: `/update/shop/backup`,
    shop: session.shop,
    accessToken: session.accessToken,
    topic: 'PRODUCTS_UPDATE',
    deliveryMethod: DeliveryMethod.Http,
})

export default async function webhookRegistry(session){
  // await response(session).then(uninstallResponse=>{
  //   console.log('installResponse',uninstallResponse);
  // });
  // await subsWebhookResponse(session).then(subResponse=>{
  //   console.log('subsResponse',subResponse);
  // });
  // await oneTimeWebhook(session).then(oneTimeUpdate=>{
  //   console.log('oneTimeUpdate',oneTimeUpdate);
  // });
  await shopifyProductUpdate(session).then(shopifyProductUpdate=>{
      console.log('shopifyProductUpdate',JSON.stringify(shopifyProductUpdate));
  })
}