import fetch from 'node-fetch';
export default function saveShopDetail(accessToken,shopDomain){
    console.log(`This is the url ${process.env.JAVA_BACKEND_URL}+/+${accessToken}?shopDomain=${shopDomain}`);
    const response =  fetch(`${process.env.JAVA_BACKEND_URL}+/+${accessToken}?shopDomain=${shopDomain}`, {
        method: 'GET', // *GET, POST, PUT, DELETE, etc.
        headers: {
            'Content-Type': 'application/json'
            // 'Content-Type': 'application/x-www-form-urlencoded',
        },

    });
}

