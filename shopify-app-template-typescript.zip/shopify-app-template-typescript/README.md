# Shopify App Node with TypeScript



## Requirements

- If you don’t have one, [create a Shopify partner account](https://partners.shopify.com/signup).
- If you don’t have one, [create a Development store](https://help.shopify.com/en/partners/dashboard/development-stores#create-a-development-store) where you can install and test your app.
- **If you are not using the Shopify CLI**, in the Partner dashboard, [create a new app](https://help.shopify.com/en/api/tools/partner-dashboard/your-apps#create-a-new-app). You’ll need this app’s API credentials during the setup process.
- You also have to install ngrok in you machine

## Quickstart

1. Clone the repo

Create a .env file
SHOPIFY_API_KEY=<Your APP KEY>
SHOPIFY_API_SECRET=<Your APP SECERT KEY>
HOST=<ngrok Tunnel host>
SHOP=<store name>
SCOPES=read_products,write_products
Then copy `.env` file to the typescript project and remove the one you just created.
set the host value in your app dashboard in partner.shopify.com
*/auth/callback
*/auth/shopify/callback
*/api/auth/callback

## Deployment

We will probably need to deploy it somewhere in the cloud when we are done with the app.

So `Dockerfile` and `Docker Compose` with `https://` setup will be coming soon...

## Enhancements

There are plans to create an advanced `shopify-app-starter` that will be powered by React Router, Mobx, a more opinionated structure, release-it, and other useful things.

## Similar starters

- [SaeedYasin/shopify-app-template](https://github.com/SaeedYasin/shopify-app-template) - fork from the current one + Prisma support added, and some other addons.

## Motivation

I started developing a Shopify app some time ago that uses NextJS and Koa, which are deprecated in favour of pure React App and Express. The codebase was primarily written using TS, and it was painful to see that Shopify doesn't provide a new template with TS setup. There is the [issue](https://github.com/Shopify/shopify-app-template-node/issues/690) since January 2022 where people ask for TS support but no luck so far. So that's how this repo was born. I tried to keep it as close as possible to the [original repo](https://github.com/Shopify/shopify-app-template-node) but with TypeScript support.

## License

This repository is available as open source under the terms of the [MIT License](https://opensource.org/licenses/MIT).
# shopify-product-backup-ui
