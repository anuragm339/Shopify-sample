/**
 * Spring Data JPA repositories.
 */
package com.product.backup.repository;
