/**
 * JPA domain objects.
 */
package com.product.backup.domain;
