package com.product.backup.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record ShopifyShopDetail( String name, String email, String id,String accessToken) {
}
