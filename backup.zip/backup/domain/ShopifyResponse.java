package com.product.backup.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public record ShopifyResponse(@JsonProperty("data") ShopifyData data) {
}
