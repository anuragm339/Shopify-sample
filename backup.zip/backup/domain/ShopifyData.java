package com.product.backup.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public record ShopifyData(@JsonProperty("shop") ShopifyShopDetail shopifyShopDetail) {
}
