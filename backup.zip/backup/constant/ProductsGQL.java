package com.product.backup.constant;

public class ProductsGQL {
    public static String GET_SHOP="{\n" +
            "  shop {\n" +
            "    name\n" +
            "     email"+
            "       id"+
            "  }\n" +
            "}";
}
