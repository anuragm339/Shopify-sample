/**
 * View Models used by Spring MVC REST controllers.
 */
package com.product.backup.web.rest.vm;
