package com.product.backup.web.rest.errors;

import org.springframework.http.HttpStatus;
import org.zalando.problem.AbstractThrowableProblem;
import org.zalando.problem.Status;

public class CustomizedException extends AbstractThrowableProblem {
    private final String code;
    private final String message;
    private final Status status;

    public CustomizedException(String message, String code, HttpStatus status) {
        super(ErrorConstants.DEFAULT_TYPE, message, Status.valueOf(status.value()), code);
        this.code = code;
        this.message = message;
        this.status = Status.valueOf(status.value());
    }

    public String getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }

    @Override
    public Status getStatus() {
        return status;
    }
}
