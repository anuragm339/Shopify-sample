package com.product.backup.web.rest;

import com.product.backup.service.ShopifyApiService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ShopifyApiRestController {
    private final ShopifyApiService shopifyApiService;

    ShopifyApiRestController(ShopifyApiService shopifyApiService){
        this.shopifyApiService=shopifyApiService;
    }

    @GetMapping("/shopify/{accessToken}")
    public String consumeShopifyDataOnFirstTimeInstall(@PathVariable(name = "accessToken") String accessToken, @RequestParam(name = "shopDomain")  String shopDomain){
        shopifyApiService.findShop(accessToken,shopDomain);
        return "String";
    }
}
