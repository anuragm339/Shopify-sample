package com.product.backup.service;

import com.product.backup.domain.ShopifyResponse;
import org.springframework.http.ResponseEntity;

import java.util.Map;

public interface ShopifyApiService {
    void findShop(String accessToken,String shopDomain);

    void createShop(ResponseEntity<ShopifyResponse> responseMap, String accessToken);


}
