package com.product.backup.service.impl;


import com.product.backup.config.ApplicationProperties;
import com.product.backup.domain.ShopifyResponse;
import com.product.backup.domain.ShopifyShopDetail;
import com.product.backup.service.ShopifyApiService;
import com.product.backup.web.rest.errors.CustomizedException;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;


import static com.product.backup.constant.ProductsGQL.GET_SHOP;


@Service
public class ShopifyApiServiceImpl implements ShopifyApiService {
    private ApplicationProperties applicationProperties;

    private RestTemplate restTemplate;


    private String shopifyApiVersion="2022-04";

    public ShopifyApiServiceImpl(ApplicationProperties applicationProperties, RestTemplate restTemplate){
        this.applicationProperties=applicationProperties;
        this.restTemplate=restTemplate;
    }
    @Override
    public void findShop(String accessToken,String shopDomain) {
        try {
            String url = "https://" + shopDomain + "/admin/api/" + shopifyApiVersion + "/graphql.json";
            HttpHeaders headers = new HttpHeaders();
            headers.add("X-Shopify-Access-Token", accessToken);
            headers.add("Content-Type", "application/graphql");
            HttpEntity<String> requestEntity = new HttpEntity<>(GET_SHOP, headers);
            ResponseEntity<ShopifyResponse> exchange = restTemplate.exchange(URI.create(url), HttpMethod.POST, requestEntity, ShopifyResponse.class);
            createShop(exchange,accessToken);
        } catch (ResourceAccessException e) {
            throw new CustomizedException(e.getMessage(), "ER006", HttpStatus.BAD_REQUEST);
        }catch (HttpStatusCodeException codeException){
            throw new CustomizedException(codeException.getMessage(), "ER006", codeException.getStatusCode());
        }
        catch (Exception exception){
            exception.printStackTrace();
        }
    }

    @Override
    @Async
    public void createShop(ResponseEntity<ShopifyResponse> exchange,String accessToken) {
        ShopifyResponse body = exchange.getBody();
        ShopifyShopDetail shopifyShopDetail = body.data().shopifyShopDetail();
        ShopifyShopDetail shopifyShopDetail1= new ShopifyShopDetail(shopifyShopDetail.name(),shopifyShopDetail.email(),shopifyShopDetail.id(),accessToken);
        //save this data
    }

}
